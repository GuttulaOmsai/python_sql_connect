import mysql.connector

# Connect to MySQL
def connect_to_mysql():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="microden@12345678",
            database="my_db"
        )
        print("Connected to MySQL!")
        return connection
    except mysql.connector.Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

# Create a table
def create_table(connection):
    try:
        cursor = connection.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255),
                email VARCHAR(255)
            )
        """)
        connection.commit()
        print("Table 'users' created successfully!")
    except mysql.connector.Error as e:
        print(f"Error creating table: {e}")

# Insert data into the table
def insert_data(connection, name, email):
    try:
        cursor = connection.cursor()
        cursor.execute("""
            INSERT INTO users (name, email) VALUES (%s, %s)
        """, (name, email))
        connection.commit()
        print("Data inserted successfully!")
    except mysql.connector.Error as e:
        print(f"Error inserting data: {e}")

# Main function
def main():
    # Connect to MySQL
    connection = connect_to_mysql()
    if connection is None:
        return

    # Create table
    create_table(connection)

    # Insert data
    name = input("Enter your name: ")
    email = input("Enter your email: ")
    insert_data(connection, name, email)

    # Close connection
    connection.close()
    print("Connection closed.")

if __name__ == "__main__":
    main()
